const express = require('express');
const exphbs = require('express-handlebars');

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.engine('handlebars', exphbs.engine({ defaultLayout: false }));
app.set("view engine", "handlebars");

//´-----------Usuários

let usuarios = [
    { id: 1, nome: 'Juliana',idade: 14, CPF: '12345645342'},
    { id: 2, nome: 'Daiane', idade: 19, CPF: '12345645344'},
    { id: 3, nome: 'Eric', idade: 33, CPF: '12345645343'},

];


app.get('/', (req, res) => {
    res.render/*renderizar a view home*/('home'); //toda iew tem por padrão'.handlebars' 
});
//LISTAR usuarios
app.get('/usuarios', (req, res) => {
    res.render('listarUsuarios', { usuarios }) /*o {usuarios} diz pra pegar os dado, renderizar e mudar a página*/

});

//CADASTRAR Usuario
app.get('/usuarios/novo', (req, res) => {
    res.render('cadastrarUsuario');
});

app.post('/usuarios', (req, res) => {
    const nome = req.body.nome;
    console.log(nome)
    const novoUsuario = {
        id: usuarios.length + 1,
        nome: nome
    };

    usuarios.push(novoUsuario);
    res.render('listarusuarios', { usuarios });
});

//Detalhar Usuario

app.get('/usuarios/:id', (req,res) => {
const id = parseInt(req.params.id);
const Usuario = usuarios.find(p => p.id === id);
if(Usuario){
    res.render('detalharUsuario', { Usuario });

}else{
    res.status(404).send('Usuario não encontrado');
}

});


//EDITAR Usuario

app.get('/usuarios/:id/editar', (req, res) => {
    const id = parseInt(req.params.id);
    const usuario = usuarios.find(p => p.id === id);

    if (!usuario) return res.status(404).send('Usuario não encontrado');

    res.render('editarUsuario', { usuario });
});

app.post('/usuarios/:id/editar', (req, res) => {
    const id = parseInt(req.params.id);
    const usuario = usuarios.find(p => p.id === id);

    if (!usuario) return res.status(404).send('Usuario não encontrado');

    usuario.nome = req.body.nome;
    res.render('listarusuarios', { usuarios });
});

//EXCLUIR Usuario

app.post('/usuarios/excluir/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = usuarios.findIndex(p => p.id === id);

    if (index === -1) return res.status(404).send('Usuario nãoencontrado');

    usuarios.splice(index, 1);
    res.redirect('/usuarios');
});
//---------ALERGIAS
let alergias = [
    { id: 1, nome: 'Frutos  do mar', descricao:'Peixes, Camarão, Caranguejo'},
    { id: 2, nome: 'Lactose', descricao:'Leite, Yogurt, queijo'},
    { id: 3, nome: 'glúten',descricao:'Trigo, Bolo, Pão'},

];


app.get('/', (req, res) => {
    res.render('home'); 
});
//LISTAR alergia
app.get('/alergias', (req, res) => {
    res.render('listarAlergia', { alergias }) 

});

//CADASTRAR alergia
app.get('/alergias/nova', (req, res) => {
    res.render('cadastrarAlergia');
});

app.post('/alergias', (req, res) => {
    const nome = req.body.nome;
    console.log(nome)
    const novaAlergia = {
        id: alergias.length + 1,
        nome: nome
    };

    alergias.push(novaAlergia);
    res.render('listarAlergia', {alergias});
});

//Detalhar Alergia

app.get('/alergias/:id', (req,res) => {
const id = parseInt(req.params.id);
const Alergias = alergias.find(p => p.id === id);
if(Alergias){
    res.render('detalharAlergias', { Alergias });

}else{
    res.status(404).send('Alergia não encontrada');
}

});


//EDITAR Alergia

app.get('/alergias/:id/editar', (req, res) => {
    const id = parseInt(req.params.id);
    const alergia = alergias.find(p => p.id === id);

    if (!alergia) return res.status(404).send('Alergia não encontrado');

    res.render('editarAlergia', { alergia });
});

app.post('/alergias/:id/editar', (req, res) => {
    const id = parseInt(req.params.id);
    const alergia= alergias.find(p => p.id === id);

    if (!alergia) return res.status(404).send('Alergia não encontrada');

    alergia.nome = req.body.nome;
    res.render('listarAlergia', {alergias});
});

//EXCLUIR alergia

app.post('/alergias/excluir/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = alergias.findIndex(p => p.id === id);

    if (index === -1) return res.status(404).send('Alergia nãoencontrado');

    alergias.splice(index, 1);
    res.redirect('/alergias');
});


app.listen(port, () => {
    console.log(`servidor em execução: http://localhost:${port}`); //tem que ser cráse
});


//-------------------------------------LET restaurantes--------------------------------

let restaurantes = [
    { id: 1, nome: 'Bistrô Do Chef', endereco: 303, CNPJ: '45.678.912/0001-34' },
    { id: 2, nome: 'Tempero da Serra', endereco: 404, CNPJ: '56.789.123/0001-56' },
    { id: 3, nome: 'Mar & Brasa Seafood', endereco: 505, CNPJ: '67.891.234/0001-78' }
];


//-------------------------------------CRUD restaurantes--------------------------------

app.get('/restaurantes', (req, res) => {
    res.render('listarRestaurantes', {restaurantes}) //o {restaurantes} diz pra pegar os dado, renderizar e mudar a página/

});

//CADASTRAR restaurantes
app.get('/restaurantes/novo', (req, res) => {
    res.render('cadastrarRestaurante');
});

app.post('/restaurantes', (req, res) => {
    const nome = req.body.nome;
    console.log(nome)
    const novoRestaurante = {
        id: restaurantes.length + 1,
        nome: nome
    };

  restaurantes.push(novoRestaurante);
    res.render('listarrestaurantes', { restaurantes });
});

//Detalhar restaurantes

app.get('/restaurantes/:id', (req,res) => {
const id = parseInt(req.params.id);
const Restaurante = restaurantes.find(p => p.id === id);
if(Restaurante){
    res.render('detalharRestaurante', { Restaurante });

}else{
    res.status(404).send('Restaurante não encontrado');
}

});


//EDITAR restaurantes

app.get('/restaurantes/:id/editar', (req, res) => {
    const id = parseInt(req.params.id);
    const restaurante = restaurantes.find(p => p.id === id);

    if (!restaurante) return res.status(404).send('Restaurante não encontrado');

    res.render('editarRestaurante', { restaurante });
});

app.post('/restaurantes/:id/editar', (req, res) => {
    const id = parseInt(req.params.id);
    const restaurante = restaurantes.find(p => p.id === id);

    if (!restaurante) return res.status(404).send('Restaurante não encontrado');

   restaurante.nome = req.body.nome;
    res.render('listarrestaurantes', { restaurantes });
});

//EXCLUIR restaurantes

app.post('/restaurantes/excluir/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = restaurantes.findIndex(p => p.id === id);

    if (index === -1) return res.status(404).send('Restaurante não encontrado');

  restaurantes.splice(index, 1);
    res.redirect('/restaurantes');
});
